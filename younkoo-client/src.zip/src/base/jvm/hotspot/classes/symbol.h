//
// Created by Administrator on 2024/3/15.
//

#ifndef SYMBOL_H
#define SYMBOL_H

#include "../include_header.h"


namespace java_hotspot {
    class symbol {
    public:

        auto to_string() -> std::string;
    };
}


#endif //SYMBOL_H
