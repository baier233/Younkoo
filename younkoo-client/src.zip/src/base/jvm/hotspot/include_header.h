﻿
#ifndef INCLUDE_HEADER_H
#define INCLUDE_HEADER_H

#include <Windows.h>

#include <iostream>
#include <cstdint>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>
#include <functional>
#include <map>


#include <jni/jni.h>
#include <jni/jvmti.h>
#endif //INCLUDE_HEADER_H
