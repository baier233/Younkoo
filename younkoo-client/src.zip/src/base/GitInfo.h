#pragma once
#define GIT_COMMIT_HASH "1cb641c"
#define GIT_COMMIT_TIME "Tue Jul 16 00:32:19 2024 +0800"
