﻿#pragma once
#include "../AbstractHook.h"
class PlayerHook : public AbstractHook
{
public:
	void hook(const HookManagerData& container) override;
private:

};

