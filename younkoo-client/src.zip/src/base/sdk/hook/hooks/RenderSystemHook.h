﻿#pragma once

#include "../AbstractHook.h"
class GameRendererHook : public AbstractHook
{
public:
	void hook(const HookManagerData& container) override;
private:

};