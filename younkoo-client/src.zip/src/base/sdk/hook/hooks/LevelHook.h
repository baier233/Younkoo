﻿#pragma once
#include "../AbstractHook.h"
class LevelHook : public AbstractHook
{
public:
	void hook(const HookManagerData& container) override;
private:

};

