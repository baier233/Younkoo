﻿#pragma once

#include <SDK.hpp>

BEGIN_1_20_1
BEGIN_KLASS_DEF(Block, return SRGParser::get().getObfuscatedClassName("net/minecraft/world/level/block/Block"))
END_KLASS_DEF();

END_1_20_1