﻿#pragma once

#include <SDK.hpp>

BEGIN_1_20_1
BEGIN_KLASS_DEF(Item, return SRGParser::get().getObfuscatedClassName("net/minecraft/world/item/Item"))

END_KLASS_DEF();
END_1_20_1;