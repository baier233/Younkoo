﻿#pragma once

#include <SDK.hpp>

BEGIN_1_18_1
BEGIN_KLASS_DEF(BlockEntity, return SRGParser::get().getObfuscatedClassName("net/minecraft/world/level/block/entity/BlockEntity"))

END_KLASS_DEF()
END_1_18_1;
