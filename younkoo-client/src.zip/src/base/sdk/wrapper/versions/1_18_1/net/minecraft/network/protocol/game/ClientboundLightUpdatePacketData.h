﻿#pragma once
#include <SDK.hpp>
BEGIN_1_18_1


BEGIN_KLASS_DEF(ClientboundLightUpdatePacketData, return SRGParser::get().getObfuscatedClassName("net/minecraft/network/protocol/game/ClientboundLightUpdatePacketData"))

END_KLASS_DEF();
END_1_18_1