﻿#pragma once

#include <SDK.hpp>

BEGIN_1_18_1
BEGIN_KLASS_DEF(ArmorItem, return SRGParser::get().getObfuscatedClassName("net/minecraft/world/item/ArmorItem"))


END_KLASS_DEF();
END_1_18_1;