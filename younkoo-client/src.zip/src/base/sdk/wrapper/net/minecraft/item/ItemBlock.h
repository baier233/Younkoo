﻿#pragma once
#include <SDK.hpp>
#include "wrapper/Object.h"

BEGIN_WRAP
class ItemBlock :public Object {
public:

	static jclass klass();
};

END_WRAP