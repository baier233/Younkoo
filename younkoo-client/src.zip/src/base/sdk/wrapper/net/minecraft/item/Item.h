﻿#pragma once
#include <wrapper/Object.h>
#include <SDK.hpp>
BEGIN_WRAP;
class Item : public Object
{
public:
	using Object::Object;
};
END_WRAP;
