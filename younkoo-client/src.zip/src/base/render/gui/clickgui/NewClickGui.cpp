﻿#include "NewClickGui.h"
