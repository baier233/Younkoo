﻿#include "BooleanValueComponent.h"
