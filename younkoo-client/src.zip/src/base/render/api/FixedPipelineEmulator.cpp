﻿#include "FixedPipelineEmulator.h"
