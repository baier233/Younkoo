﻿#pragma once
#include "../NanovgHelper.hpp"
namespace gl3
{
	NVGcontext* init();
	void clean(NVGcontext* vg);
}

