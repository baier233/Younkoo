﻿#pragma once
#include "../NanovgHelper.hpp"
namespace gl2
{
	NVGcontext* init();
	void clean(NVGcontext* vg);
}

