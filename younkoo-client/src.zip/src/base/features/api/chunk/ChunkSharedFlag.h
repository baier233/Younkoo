﻿#pragma once
namespace ChunkSharedFlag {
	inline bool updating = false;
}