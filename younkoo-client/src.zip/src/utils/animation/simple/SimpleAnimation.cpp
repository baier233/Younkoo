﻿#include "SimpleAnimation.h"
