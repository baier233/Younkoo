﻿#include "Misc.hpp"


#include <Windows.h>
#include <iostream>
